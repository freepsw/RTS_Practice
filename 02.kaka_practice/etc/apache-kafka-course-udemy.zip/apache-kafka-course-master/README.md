# apache-kafka-course
This repository is for the Apache Kafka Course
