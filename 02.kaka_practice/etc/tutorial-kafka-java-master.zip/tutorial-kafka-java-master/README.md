# Tutorial Kafka Using Java

## You can find it in our Medium publication
[Pharos Production Medium Article - Kafka Using Java](https://medium.com/pharos-production/kafka-using-java-e10bfeec8638).

Also you're warmely welcome to say hello to us
[Pharos Production - Blockchain and FinTech Software Development](https://pharosproduction.com)
